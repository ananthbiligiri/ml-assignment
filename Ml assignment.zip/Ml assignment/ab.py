import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Load the dataset
file_path = 'path_to_your_file/ingredients.csv'
data = pd.read_csv("C:/Users/SAHYADRI/Documents/New folder/ingredients.csv")

# Fill missing values in 'PortionUOMTypeId' with the median value
data['PortionUOMTypeId'].fillna(data['PortionUOMTypeId'].median(), inplace=True)

# Encode categorical variables using LabelEncoder
label_encoder = LabelEncoder()
data['IngredientName'] = label_encoder.fit_transform(data['IngredientName'])
data['IngredientShortDescription'] = label_encoder.fit_transform(data['IngredientShortDescription'])

# Define features and target variable
X = data.drop(['PortionUOMTypeId'], axis=1)
y = data['PortionUOMTypeId']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the Linear Regression model
lr = LinearRegression()
lr.fit(X_train, y_train)

# Predict on the test set
y_pred_lr = lr.predict(X_test)

# Plot the results for Linear Regression
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_lr, color='blue', label='Predicted')
plt.plot(y_test, y_test, color='red', linewidth=2, label='Actual')
plt.xlabel('Actual PortionUOMTypeId')
plt.ylabel('Predicted PortionUOMTypeId')
plt.title('Linear Regression: Actual vs Predicted')
plt.legend()
plt.show()
