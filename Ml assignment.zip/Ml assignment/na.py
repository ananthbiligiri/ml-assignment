import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

# Load the dataset
file_path = '/mnt/data/ingredients.csv'
data = pd.read_csv(f"C:/Users/SAHYADRI/Documents/New folder/ingredients.csv")

# Fill missing values in 'PortionUOMTypeId' with the median value
data['PortionUOMTypeId'].fillna(data['PortionUOMTypeId'].median(), inplace=True)

# Encode categorical variables using LabelEncoder
label_encoder = LabelEncoder()
data['IngredientName'] = label_encoder.fit_transform(data['IngredientName'])
data['IngredientShortDescription'] = label_encoder.fit_transform(data['IngredientShortDescription'])

# Define features and target variable
X = data.drop(['PortionUOMTypeId'], axis=1)
y = data['PortionUOMTypeId']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the Naive Bayes model
nb = GaussianNB()
nb.fit(X_train, y_train)

# Predict on the test set
y_pred_nb = nb.predict(X_test)

# Evaluate the model
print("Classification Report:\n", classification_report(y_test, y_pred_nb))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_nb))

# Plot the confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred_nb)
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='coolwarm')
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()
